//
//  SearchUserModel.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 14/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//

import UIKit

struct UserResptModel : Codable {
    var totalCount: Int?
        var records : [UserList]?
        enum CodingKeys: String, CodingKey {
            case totalCount = "total_count"
            case records    = "items"
        }
}

struct UserList: Codable {
        var name: String?
        var avatarUrl: String?
    var nodeId : String?
    var userId : Double?
    var score : Int?

    enum CodingKeys: String, CodingKey {
            case name = "login"
            case avatarUrl = "avatar_url"
            case userId = "id"
            case nodeId = "node_id"
            case score = "score"
        }
}
