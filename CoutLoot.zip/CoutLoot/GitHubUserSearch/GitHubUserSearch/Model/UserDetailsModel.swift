//
//  UserDetailsModel.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 15/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//

import UIKit

struct FollowersList: Codable {
        var name: String?
        var avatarUrl: String?
    var nodeId : String?
    var userId : Double?
    var score : Int?

    enum CodingKeys: String, CodingKey {
            case name = "login"
            case avatarUrl = "avatar_url"
            case userId = "id"
            case nodeId = "node_id"
            case score = "score"
        }
}
