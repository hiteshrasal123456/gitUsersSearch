//
//  Enums.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 14/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//
import Foundation
import UIKit
//MARK:- Storyboard
enum Storyboard {
    case main
    var identifier : UIStoryboard {
        switch self {
        case .main:
            return UIStoryboard(name: "Main", bundle:nil)
        }
    }
}
//MARK:- ViewController 
enum ViewControllers : String {
    case searchUserVc
    case userDetailsVC
    var identifier : String {
        switch self {
        case .searchUserVc:
            return "SearchUserVc"
        case .userDetailsVC:
            return "UserDetailsVC"
        }
    }
}
//MARK:- TableViewCell
enum TableViewCell : String {
    case userListCell
    
    var identifier : String {
        switch self {
        case .userListCell:
            return "UserListCellIdef"
         }
    }
}
//MARK: ERROR MSG
enum ErrorMsg: String {
    case pleaseTryAgain = "Please try again."
    case noRecords = "No records found."
}
