//
//  Constant.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 14/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//

import UIKit
import Foundation
// MARK: GLOBAL VARIABLE
let themeColor  = UIColor.init(red: 42.0/255.0, green: 45.0/255.0, blue: 47.0/255.0, alpha: 1.0)
let titleColor = UIColor.white
let grayColor  = UIColor.lightGray
let navBarFontStyle = "HelveticaNeue-Bold"
let indicatorColor = UIColor(displayP3Red: 255.0/255.0, green: 18.0/255.0, blue: 0.0/255.0, alpha: 1.0)
