//
//  MethodHelper.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 14/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//

import UIKit
import Foundation
/*
Method Name   : setAppThemeProperties
Functionality : SET NAVIGATION BAR THEME
*/
public func setAppThemeProperties() {
    /*** Navigation Bar Appearance ***/
    UINavigationBar.appearance().tintColor = themeColor
    UINavigationBar.appearance().barTintColor = themeColor
    UINavigationBar.appearance().isTranslucent = false
    UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor: grayColor, NSAttributedString.Key.font : UIFont(name: navBarFontStyle, size: 20) ?? UIFont.systemFont(ofSize: 18)]
}
/*
Method Name   : showAlert
Functionality : DISPLAY POPUP
*/
public func showAlert(_ message : String, viewController : UIViewController, okayButtonTapped : @escaping () -> Void) {
    let alert = UIAlertController(title: "Message", message: message, preferredStyle: UIAlertController.Style.alert)
    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action: UIAlertAction!) in
        okayButtonTapped()
    }))
    viewController.present(alert, animated: true, completion: nil)
}
/*
Method Name   : printLog
Functionality : PRINT LOG
*/
public func printLog(val: Any?, comment:String) {
    if let val = val {print("\(comment) - \(val)")} else {print("\(comment)")}
}
//MARK: UISEARCH BAR
extension UISearchBar {
    func getTextField() -> UITextField? { return value(forKey: "searchField") as? UITextField }
    func setTextField(color: UIColor) {
        guard let textField = getTextField() else { return }
        switch searchBarStyle {
        case .minimal:
            textField.layer.backgroundColor = color.cgColor
            textField.layer.cornerRadius = 6
        case .prominent, .default: textField.backgroundColor = color
        @unknown default: break
        }
    }
}


