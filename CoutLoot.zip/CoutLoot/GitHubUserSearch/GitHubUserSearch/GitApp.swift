//
//  GitApp.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 14/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//

import UIKit
//App's sharedInstance
final class GitApp {
    static let appInstance =  GitApp()
    let networkClient : NetworkClient!
    private init() {
        networkClient = NetworkClient()
    }
}
