//
//  MovieAPP.swift
//  MoviesDetailsApp
//
//  Created by Hitesh Rasal on 12/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//

import UIKit

final class MovieAPP {
    //MARK : SHARED INSTANCE
    static let appInstance = MovieAPP()
    let networkClient : NetworkClient!
    private init() {
        networkClient = NetworkClient()
    }
}
