//
//  SearchUserVM.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 14/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//

import UIKit

class SearchUserVM {
    var pageCount : Int?
    var totalCount: Int?
    var userRecords:[UserList]?
    /*
    Method Name   : fetchUserList
    Functionality : API REQUEST TO FETCH USER LIST
    */
    func fetchUserList(pageCount:Int,userName: String,completionHandler: @escaping (_ errorMsg: String?) -> Void) {
        GitApp.appInstance.networkClient.ApiRequestwith(inpParam: nil, methodName: HttpMethodType.get.rawValue, apiName: .apiUserList,pageCount: pageCount, userName: userName) { [weak self] (error, result, response) in
            
            if error == nil {
                do {
                    let data =  try JSONSerialization.data(withJSONObject: result as! [String: Any], options: .prettyPrinted)
                    print("user list resp \(result as! [String: Any])")
                    let userRecords = try JSONDecoder().decode(UserResptModel.self, from: data)
                    if self?.userRecords == nil {
                        self?.userRecords = userRecords.records
                    } else {
                        if userRecords.records != nil {
                            self?.userRecords! += userRecords.records!
                            
                        }
                    }
                    
                    completionHandler(nil)
                } catch let error {
                    completionHandler(error.localizedDescription)
                }
            } else {
                completionHandler(error?.localizedDescription)
            }
        }
    }
}
