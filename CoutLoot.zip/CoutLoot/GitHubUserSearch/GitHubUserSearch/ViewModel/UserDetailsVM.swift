//
//  UserDetailsVM.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 15/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//

import UIKit

class UserDetailsVM {
    var followersRecords:[FollowersList]?
    /*
    Method Name   : fetchFollowersList
    Functionality : API REQUEST TO FETCH FOLLOWERS LIST
    */
    func fetchFollowersList(userName: String,completionHandler: @escaping (_ errorMsg: String?) -> Void) {
        GitApp.appInstance.networkClient.ApiRequestwith(inpParam: nil, methodName: HttpMethodType.get.rawValue, apiName: .apiFollowersList,pageCount: nil, userName: userName) { [weak self] (error, result, response) in
            
            if error == nil {
                do {
                    let data =  try JSONSerialization.data(withJSONObject: result as! [[String: Any]], options: .prettyPrinted)
                    print("followers list resp \(result as! [[String: Any]])")
                    let followersRecords = try JSONDecoder().decode([FollowersList].self, from: data)
                    if self?.followersRecords == nil {
                        self?.followersRecords = followersRecords
                    }
                    
                    completionHandler(nil)
                } catch let error {
                    completionHandler(error.localizedDescription)
                }
            } else {
                completionHandler(error?.localizedDescription)
            }
        }
    }
}
