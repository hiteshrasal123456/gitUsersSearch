//
//  UserListCell.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 14/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//

import UIKit
import AnimatedGradientView

class UserListCell: UITableViewCell {
    
    @IBOutlet weak var posterImg: UIImageView!
    
    @IBOutlet weak var containerVw: AnimatedGradientView!
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var subContainerVw: UIView!
    @IBOutlet weak var lblUserId: UILabel!
    @IBOutlet weak var lblNodeId: UILabel!
    @IBOutlet weak var lblScore: UILabel!
    //GIT USER OBJ
    var userObj: UserList? {
        didSet {
            lblTitle.text = "Name: " + (userObj?.name ?? "")
            lblUserId.text = "User ID: " + "\(userObj?.userId ?? 0)"
            lblNodeId.text = "Node ID: " + (userObj?.nodeId ?? "")
            lblScore.text = "Score: " + "\(userObj?.score ?? 0)"
            if let posterPath = userObj?.avatarUrl {
                posterImg.cacheImage(urlString: posterPath) }
        }
    }
    //FOLLOWERS OBJ
    var followerObj: FollowersList? {
        didSet {
            lblTitle.text = "Name: " + (followerObj?.name ?? "")
            lblUserId.text = "User ID: " + "\(followerObj?.userId ?? 0)"
            lblNodeId.text = "Node ID: " + (followerObj?.nodeId ?? "")
            lblScore.text = "Score: " + "\(followerObj?.score ?? 0)"
            if let posterPath = followerObj?.avatarUrl {
                posterImg.cacheImage(urlString: posterPath) }
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        posterImg.circularImg()
        animateView()
    }
    
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    /*
    Method Name   : animateView
    Functionality : MAKE CONTINUOUS ANIMATION WITH GRADIENT COLOR
    */
    func animateView()  {
        containerVw.animationDuration = 1.0
        containerVw.animationValues = [(colors: ["#833ab4", "#fd1d1d", "#fcb045"], .up, .axial),
        (colors: ["#FEAC5E", "#C779D0", "#fcb045"], .upRight, .axial),
        
        (colors: ["#00bf8f", "#001510"], .down, .axial),
        (colors: ["#E55D87", "#5FC3E4"], .downLeft, .axial),
        (colors: ["#fc00ff", "#00dbde"], .left, .axial),
        (colors: ["#4568DC", "#B06AB3"], .upLeft, .axial)]
    }
    
    
}
