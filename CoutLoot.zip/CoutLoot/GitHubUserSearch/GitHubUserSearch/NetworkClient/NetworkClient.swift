
import UIKit

//
//  NetworkClient.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 14/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//
import UIKit

let timeInterval : Double  = 100
let BaseUrl      : String  = "https://api.github.com"

//MARK : END POINTS FOR URL
enum EndPoints : String {
    case userListUrl = "/search/users?q"
    case followersListUrl = "/users/"
    
    
}
//MARK : API POINTS
enum APIPoints: String {
    case apiUserList
    case apiFollowersList
    
    
}
//MARK : HTTP METHODS
enum HttpMethodType : String {
    case get = "GET"
    case post = "POST"
}


class NetworkClient: NSObject {
    /*
     Method Name   : makeApiTypeRequest
     Functionality : make diffrent type of url request
     */
    func makeApiTypeRequest(urlString: String, methodName: String , inpParam: Any?) -> URLRequest {
        let urlForRequest = urlString
        let strEscaped = urlForRequest.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        let strUrl = URL(string: strEscaped!)
        var request = URLRequest(url: strUrl!, cachePolicy: .reloadIgnoringCacheData, timeoutInterval: timeInterval)
        if methodName == HttpMethodType.get.rawValue {
            let headers = [
                "Content-Type": "application/json",
            ]
            request.allHTTPHeaderFields = headers
        } else if methodName == HttpMethodType.post.rawValue {
            let headers = [
                "Content-Type": "application/json",
            ]
            request.allHTTPHeaderFields = headers
            if inpParam != nil {
                request.httpBody =  try? JSONSerialization.data(withJSONObject: inpParam!, options: [])
            }
        }
        
        request.httpMethod = methodName
        return request;
    }
    
    /*
    Method Name   : apiReq
    Functionality : FOR HANDLING API RESPONSE
    */
    func apiReq(request: URLRequest ,completionHandlerForResp:@escaping (_ responseHttp:HTTPURLResponse? , _ respData: Data? , _ error: Error? ) -> Void) {
        
        printLog(val: Date(), comment: "Start:")
        printLog(val: request.url?.absoluteString, comment: "request final url:")
        
        DispatchQueue.global(qos: .background).async {
            
            let sessionConfig = URLSessionConfiguration.default
            sessionConfig.timeoutIntervalForRequest  = timeInterval
            sessionConfig.timeoutIntervalForResource = timeInterval
            
            (URLSession(configuration: URLSessionConfiguration.default)).dataTask(with: request, completionHandler: {(respData, responseHttp, error) in
                DispatchQueue.main.async {
                    printLog(val: Date(), comment: "End:")
                    if error != nil
                    {
                        completionHandlerForResp(responseHttp as? HTTPURLResponse,respData, error)
                    }
                    
                    if (responseHttp as? HTTPURLResponse) != nil
                    {
                        if (responseHttp as? HTTPURLResponse)?.statusCode == 200
                        {
                            completionHandlerForResp(responseHttp as? HTTPURLResponse,respData, error)
                        }
                        else if (responseHttp as? HTTPURLResponse)?.statusCode == 401
                        {
                            completionHandlerForResp(responseHttp as? HTTPURLResponse,respData, error)
                        }
                        else if (responseHttp as? HTTPURLResponse)?.statusCode == 404
                        {
                            completionHandlerForResp(responseHttp as? HTTPURLResponse,respData, error)
                        }
                        else if (responseHttp as? HTTPURLResponse)?.statusCode == 400
                        {
                            completionHandlerForResp(responseHttp as? HTTPURLResponse,respData, error)
                        }
                        else if (responseHttp as? HTTPURLResponse)?.statusCode == 422
                        {
                            completionHandlerForResp(responseHttp as? HTTPURLResponse,respData, error)
                        }
                        else
                        {
                            completionHandlerForResp(responseHttp as? HTTPURLResponse,respData, error)
                        }
                    }
                }
            }).resume()
            
        }
    }
    /*
    Method Name   : ApiRequestwith
    Functionality : HANDLING INPUT PARAMETER ,API POINTS AND IT WILL RETURN THE RESPONSE
    */
    func ApiRequestwith(inpParam : Any?,methodName: String ,apiName: APIPoints ,pageCount: Int?, userName: String, completionHandlerForResp : @escaping (_ error: Error? , _ result:Any , _ responseHttp:HTTPURLResponse?) -> Void) {
        
        var request: URLRequest!
        
        request = self.makeApiTypeRequest(urlString: UrlStringForAPI(apiName: apiName,pageCount: pageCount, userName: userName) , methodName: methodName, inpParam: inpParam)
        self.apiReq(request: request) { (responseHttp, respData, error) in
            if error == nil {
                if respData != nil {
                    let result = try? JSONSerialization.jsonObject(with: respData!, options: JSONSerialization.ReadingOptions.mutableContainers)
                    completionHandlerForResp(error,result as Any,responseHttp!)
                } else {
                    completionHandlerForResp(error,respData as Any,responseHttp!)
                }
            } else {
                completionHandlerForResp(error,respData as Any,responseHttp)
            }
            
        }
    }
    
    /*
    Method Name   : UrlStringForAPI
    Functionality : CREATE URL STRING FOR URL REQUEST
    */
    func UrlStringForAPI(apiName: APIPoints, pageCount: Int?, userName: String) -> String
    {
        var url: String!
        switch apiName {
        case .apiUserList:
            if let pageCount = pageCount {
                url = String("\(BaseUrl)\(EndPoints.userListUrl.rawValue)=\(userName)&page=\(pageCount)")
            }
        case .apiFollowersList:
                url = String("\(BaseUrl)\(EndPoints.followersListUrl.rawValue)\(userName)/followers")
        
        }
        return url
    }
}


