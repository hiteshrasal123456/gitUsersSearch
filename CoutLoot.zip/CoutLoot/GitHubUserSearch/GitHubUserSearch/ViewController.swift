//
//  ViewController.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 14/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

