//
//  UIImageView+Extension.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 14/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//

import UIKit
import Foundation

let imageCache = NSCache<AnyObject, AnyObject>()

extension UIImageView {
    /*
    Method Name   : circularImg
    Functionality : MAKE IMAGE SHAPE CIRCULAR
    */
    func circularImg() {
        self.layer.cornerRadius = self.frame.height/2
        self.layer.borderColor = UIColor.white.cgColor
        self.layer.borderWidth = 2.0
        self.layer.masksToBounds = true
    }
  /*
  Method Name   : cacheImage
  Functionality : DOWNLOAD IMAGE BY IMAGE URL USING CACHE
  */
  func cacheImage(urlString: String) {
    let url = URL(string: urlString)
    image = nil
    
    if let imageFromCache = imageCache.object(forKey: urlString as AnyObject) as? UIImage {
        self.image = imageFromCache
        return
    }
        
    URLSession.shared.dataTask(with: url!) {
        data, response, error in
          if let data = data {
              DispatchQueue.main.async {
                  let imageToCache = UIImage(data: data)
                  imageCache.setObject(imageToCache!, forKey: urlString as AnyObject)
                  self.image = imageToCache
              }
          }
     }.resume()
  }
    
}
