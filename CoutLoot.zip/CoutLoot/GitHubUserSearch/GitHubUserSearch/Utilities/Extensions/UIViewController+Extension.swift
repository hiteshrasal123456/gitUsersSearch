//
//  UIViewController+Extension.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 14/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//

import UIKit
import Foundation
import NVActivityIndicatorView

extension UIViewController : NVActivityIndicatorViewable {
    /*
    Method Name   : setBackImageWithTitle
    Functionality : CREATE BACK BUTTON AMD MANAGE ITS IMAGE
    */
    public func setBackImageWithTitle(imageName: String, title : String)
    {
        let bckButtonView = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: 33))
        bckButtonView.backgroundColor = UIColor.clear
        
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(customView: bckButtonView)
        
        let imageView = UIImageView(frame: CGRect(x: -10, y: 0, width: 25, height: bckButtonView.frame.size.height))
        imageView.tintColor = grayColor
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: imageName)
        bckButtonView.addSubview(imageView)
        
        let titleLabel = UILabel(frame: CGRect(x: imageView.frame.maxX + 5, y: 0, width: 0, height: bckButtonView.frame.size.height))
        titleLabel.backgroundColor = UIColor.clear
        titleLabel.text = title
        titleLabel.numberOfLines = 2
        titleLabel.lineBreakMode = .byTruncatingTail
        titleLabel.adjustsFontSizeToFitWidth = true
        titleLabel.textColor = grayColor
        titleLabel.font = UIFont(name: navBarFontStyle, size: 20)
        titleLabel.textAlignment = .left
        bckButtonView.addSubview(titleLabel)
        
        titleLabel.frame.size.width = self.view.frame.size.width - 180
        
        let buttonTapped = UIButton(frame: CGRect(x: 0, y: 0, width: 70, height: bckButtonView.frame.size.height))
        buttonTapped.backgroundColor = UIColor.clear
        buttonTapped.addTarget(self, action: #selector(onLeftButtonTapped), for: .touchUpInside)
        bckButtonView.addSubview(buttonTapped)
        
        bckButtonView.frame.size.width = titleLabel.frame.size.width
    }
    /*
    Method Name   : onLeftButtonTapped
    Functionality : BACK BUTTON ACTION FOR NAVIGATING TO PREVIOUS CONTROLLER
    */
    @objc func onLeftButtonTapped(){
        DispatchQueue.main.async {
            self.navigationController?.popViewController(animated: true)
        }
    }
    // MARK: ACTIVITY INDICATOR
    /*
    Method Name   : showActivityIndicatorWith
    Functionality : DISPLAY LODING INDICATOR AND MANAGE ITS FONT AND COLOR
    */
    public func showActivityIndicatorWith(message: String) {
        startAnimating(message: message, messageFont: UIFont(name: navBarFontStyle, size: 15), type: .orbit, color: indicatorColor, textColor: indicatorColor)
    }
    /*
    Method Name   : hideActivityIndicator
    Functionality : HIDING LODING INDICATOR
    */
    public func hideActivityIndicator() {
        stopAnimating()
    }
}
