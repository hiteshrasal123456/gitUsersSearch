//
//  UIView+Extension.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 14/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//
import Foundation
import UIKit
extension UIView {
//TO SET VIEW CORNER RADIUS
@IBInspectable var cornerRadius: CGFloat {
    get {
        return layer.cornerRadius
    }
    set {
        layer.cornerRadius = newValue
        layer.masksToBounds = newValue > 0
    }
  }
}
