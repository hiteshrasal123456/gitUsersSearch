//
//  SearchUserVc.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 14/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//

import UIKit

class SearchUserVc: UIViewController {
    
    @IBOutlet weak var tblView: UITableView!
    var searchUserVmObj = SearchUserVM()
    @IBOutlet weak var searchBar: UISearchBar!
    override func viewDidLoad() {
        super.viewDidLoad()
        configUI()
    }
    /*
    Method Name   : configUI
    Functionality : CONFIGURE UI
    */
    func configUI() {
        self.title = "Search Git User"
        self.tblView.tableFooterView = UIView()
        self.tblView.delegate = self
        self.tblView.dataSource = self
        self.tblView.register(UINib(nibName: "UserListCell", bundle: nil), forCellReuseIdentifier: TableViewCell.userListCell.identifier)
        self.searchBar.delegate = self
        self.searchBar.showsCancelButton = false
        self.searchBar.setTextField(color: UIColor.white)
        let searchBarStyle = self.searchBar.value(forKey: "searchField") as? UITextField
        searchBarStyle?.clearButtonMode = .never
        
    }

    
    /*
    Method Name   : searchApi
    Functionality : SEARCH GIT USER'S API
    */
    func searchApi(searchText:String) {
        var pageNo : Int!
        if let pageCount = searchUserVmObj.pageCount {
            pageNo = pageCount
        } else {
            pageNo = 1
        }
        showActivityIndicatorWith(message: "Loading")
        searchUserVmObj.fetchUserList(pageCount: pageNo, userName: searchText) {[weak self] (errorMsg) in
            DispatchQueue.main.async {
                self?.hideActivityIndicator()
                if errorMsg == nil {
                    self?.tblView.reloadData()
                } else {
                    showAlert(errorMsg!, viewController: self!) {}
                }
            }
        }
    }
    
    /*
     Method Name   : naviToDetailsScreen
     Functionality : NAVIGATE TO MOVIE DETAILS SCREEN
     */
    func naviToDetailsScreen(userObj: UserList) {
        DispatchQueue.main.async {
            let detailsScreenObj = Storyboard.main.identifier.instantiateViewController(identifier: ViewControllers.userDetailsVC.identifier) as! UserDetailsVC
            detailsScreenObj.userListObj = userObj
            self.navigationController?.pushViewController(detailsScreenObj, animated: true)
        }
    }

}
//MARK: UISEARCHBAR DELEGATE METHODS
extension SearchUserVc : UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.count >= 3 {
            searchUserVmObj.pageCount = 1
            DispatchQueue.main.async {
                searchBar.resignFirstResponder()
                self.searchApi(searchText: searchText)
            }
        } else if searchText.count == 0 {
            searchBar.resignFirstResponder()
        }
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        DispatchQueue.main.async {
            searchBar.endEditing(true)
        }
        
    }
}

// MARK : UITABLEVIEW DELEGATE AND DATASOURCE METHODS
extension SearchUserVc: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchUserVmObj.userRecords?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: TableViewCell.userListCell.identifier) as! UserListCell
        cell.userObj = searchUserVmObj.userRecords?[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let userListObj = searchUserVmObj.userRecords?[indexPath.row]
        if let userListObj = userListObj {
            naviToDetailsScreen(userObj: userListObj)

        }
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if searchUserVmObj.userRecords != nil {
            if searchUserVmObj.userRecords!.count > 0 {
                if indexPath.row == searchUserVmObj.userRecords!.count - 1 {
                    if searchUserVmObj.totalCount != searchUserVmObj.userRecords!.count {
                        searchUserVmObj.pageCount! += 1
                        self.searchApi(searchText: self.searchBar.text!)
                    }
                }
            }
        }
    }
}
