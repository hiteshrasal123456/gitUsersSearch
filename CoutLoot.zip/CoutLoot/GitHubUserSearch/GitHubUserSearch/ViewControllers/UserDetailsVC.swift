//
//  UserDetailsVC.swift
//  GitHubUserSearch
//
//  Created by Hitesh Rasal on 15/07/20.
//  Copyright © 2020 Hitesh Rasal. All rights reserved.
//

import UIKit

class UserDetailsVC: UIViewController {
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var posterImg: UIImageView!
    @IBOutlet weak var lblFollowers: UILabel!
    @IBOutlet weak var lblScore: UILabel!
    var userListObj : UserList?
    var userDetailsVmObj = UserDetailsVM()
    override func viewDidLoad() {
        super.viewDidLoad()
        configUI()
        // Do any additional setup after loading the view.
        
    }
    /*
    Method Name   : configUI
    Functionality : CONFIGURE UI
    */
    func configUI()  {
        self.setBackImageWithTitle(imageName: "back", title: "User Details")
        self.posterImg.circularImg()
        if let userListObj = self.userListObj {
            self.lblName.text = "Name: " + (userListObj.name ?? "")
            self.lblScore.text = "Score: " + "\(userListObj.score ?? 0)"
            if let imgUrl = userListObj.avatarUrl {
                self.posterImg.cacheImage(urlString: imgUrl)

            }
            self.tblView.tableFooterView = UIView()
            self.tblView.delegate = self
            self.tblView.dataSource = self
            self.tblView.register(UINib(nibName: "UserListCell", bundle: nil), forCellReuseIdentifier: TableViewCell.userListCell.identifier)
            fetchFollowers(userName: userListObj.name!)
        }

    }
    /*
    Method Name   : fetchFollowers
    Functionality : FETCH USER'S FOLLOWERS LIST FROM API
    */
    func fetchFollowers(userName: String) {
            showActivityIndicatorWith(message: "Loading")
            userDetailsVmObj.fetchFollowersList(userName: userName) {[weak self] (errorMsg) in
                DispatchQueue.main.async {
                    self?.hideActivityIndicator()
                    if errorMsg == nil {
                        if let followersRecords = self?.userDetailsVmObj.followersRecords {
                            self?.lblFollowers.text = "Followers: " + "\(followersRecords.count)"
                            self?.tblView.reloadData()
                        }
                    } else {
                        showAlert(errorMsg!, viewController: self!) {}
                    }
                }
                
                
            }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
// MARK : UITABLEVIEW DELEGATE AND DATASOURCE METHODS
extension UserDetailsVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userDetailsVmObj.followersRecords?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: TableViewCell.userListCell.identifier) as! UserListCell
        cell.followerObj = userDetailsVmObj.followersRecords?[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    

}
